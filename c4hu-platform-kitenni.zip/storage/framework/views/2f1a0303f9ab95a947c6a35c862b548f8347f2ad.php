<?php $__env->startSection('content'); ?>
<div>
	    	<?php echo $__env->make('popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            <div class="pageBody max-w-6xl mx-auto sm:px-6 lg:px-8">
           		<h2><?php echo e(env('APP_NAME')); ?></h2>	
            	<img src="/images/logo.png" class="logo" />
				<?php if(count($errors) > 0): ?>
				   <div class = "alert alert-danger">
				      <ul>
				         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <li><?php echo e(__('project.'.$error)); ?></li>
				         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </ul>
				   </div>
				<?php endif; ?>            
            	<ul class="nav nav-tabs">
					<li class="active">
						<a href="#"><?php echo e(__('project.info')); ?></a>
					</li>
  					<li>
  						<a href="<?php echo e(\URL::to('/contributors/'.$project->id)); ?>"><?php echo e(__('project.contributors')); ?></a>
  					</li>
				</ul>
                <div class="projectForm">
                	<form method="POST" action="<?php echo e(\URL::to('/project')); ?>" id="frmProject">
		            	<h3><?php echo e(__('project.project')); ?></h3>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($project->id); ?>" />
                        <input type="hidden" name="user_id" value="<?php echo e(\Auth::user()->id); ?>" />
	                    <div class="form-group">
                            <div class="input-group">
                                    <img class="avatar" src="<?php echo e($project->avatar); ?>" />
                            </div>        
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('project.name')); ?>

                                    </span>
                                </div>
                                <input type="text" class="form-control" name="name" 
                                size="80" value="<?php echo e($project->name); ?>" />
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('project.avatar')); ?>

                                    </span>
                                </div>
                                <input type="text" class="form-control" name="avatar" 
                                size="80" value="<?php echo e($project->avatar); ?>" />
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('project.organisation')); ?>

                                    </span>
                                </div>
                                <input type="text" class="form-control" name="organisation" 
                                size="80" value="<?php echo e($project->organisation); ?>" />
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('project.website')); ?>

                                    </span>
                                </div>
                                <input type="text" class="form-control" name="website" 
                                size="80" value="<?php echo e($project->website); ?>" />
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('project.deadline')); ?>

                                    </span>
                                </div>
                                <input type="text" class="form-control" name="deadline" 
                                size="80" value="<?php echo e($project->deadline); ?>" />
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('project.status')); ?>

                                    </span>
                                </div>
                                <select class="form-control" name="status" id="status">
                                	<option value="plan"><?php echo e(__('project.plan')); ?></option>
                                	<option value="task"><?php echo e(__('project.task')); ?></option>
                                	<option value="inprogress"><?php echo e(__('project.inprogress')); ?></option>
                                	<option value="suspended"><?php echo e(__('project.suspended')); ?></option>
                                	<option value="canceled"><?php echo e(__('project.canceled')); ?></option>
                                	<option value="closed"><?php echo e(__('project.closed')); ?></option>
                                </select> 
                            </div>
                        </div>

	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('project.description')); ?>

                                    </span>
                                </div>
                                <textarea cols="80" rows="10" class="form-control" name="description"><?php echo e($project->description); ?></textarea>  
                            </div>
                        </div>

                        <div class="skillsBlock">
			                <div class="row">
				                <h3><?php echo e(__('project.skills')); ?></h3>
			                </div>
			                <div class="row">
				                <div class= "col-sm-6" id="skillsTree"></div>
				                <div class= "col-sm-6" id="skillLevels"></div>
			                </div>
		                </div>
	                    <div class="form-group">
	                    	<button type="button" class="btn btn-primary" id="btnSave">
	                    		<em class="fa fa-check"></em>
	                    		<?php echo e(__('project.save')); ?>

	                    	</button>
						</div>
						<input type="hidden" id="skills" name="skills" value='<?php echo $skills; ?>' />					
                    </form>
                </div>
        </div>
        <script src="/js/tree.js"></script>
        <script type="text/javascript">
        $(function() {
        	// JQuery onload
        	
        	// status select beállítása
        	$('#status').val('<?php echo e($project->status); ?>');
        	
			// {az aktuális user képességei skillId:skillLevel, ....}
        	var skills = JSON.parse($('#skills').val());
        	
       		/* 
       		* skilss objektum kialakitása a skillTre és aképernyőn lévő adatokból,
       		* beirása a rejtett input mezőbe
       		*/
        	setSkillsFromScreen = function() {
        		if (skillTree) {
					skills = {};
				    for(i = 0; i < skillTree.values.length; i++) {
				    	let value = skillTree.values[i];
			    		skills[value] = '';
					}			
					$('#skills').val(JSON.stringify(skills));
				}
        	};
        	
			/**
			* btnSave click - skills rejtett input mező feltöltése, form submit
			*/
        	$('#btnSave').click(function() {
					setSkillsFromScreen();
					$('#frmProject').submit();
        	});
        	
			// skills objektumból values array-t képez        	
        	let valuesArray = [];
		    for (const [key, value] of Object.entries(<?php echo $skills; ?>)) {
		    	valuesArray.push(key);
        	}

        	// skill fa megjelenitő init
        	var skillTree = new Tree('#skillsTree', {
                		data: <?php echo $skillsTree; ?>,
                		closeDepth:1,
                		values: valuesArray,
                		onChange: function() {
						    var i = 0;
					    	setSkillsFromScreen();
						    $('#skillLevels').html('');
						    for(i = 0; i < this.values.length; i++) {
						    	let node = this.nodesById[this.values[i]];
						    	let p = '<var>'+node.text+'</var>, ';
						    	$('#skillLevels').append(p);
						    } 
  						},
                	});
                });	
         </script>       	
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/c4hu-platform/resources/views/project.blade.php ENDPATH**/ ?>