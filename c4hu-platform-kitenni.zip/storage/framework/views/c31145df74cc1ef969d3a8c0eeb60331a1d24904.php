<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
    	<?php echo $__env->make('htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="antialiased">
        <div id="app" class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center sm:pt-0">
	    	<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="pageBody sysadmins">
				<h2><?php echo e(__('profile.sysadmins')); ?></h2>
				<table class="table table-stripped">
					<thead class="thead-dark">
						<tr>
							<th>ID</th>
							<th><?php echo e(__('profile.name')); ?></th>
							<th>&nbsp;</th>
						</tr>
					</thead>
					<tbody>
					<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($item->id); ?></td>
							<td><?php echo e($item->name); ?></td>
							<td>
							<?php if($item->id != \Auth::user()->id): ?>
							<a class="btn btn-danger" 
								href="<?php echo e(\URL::to('/profilesetsysadmin/'.$item->id.'/del')); ?>">
								<?php echo e(__('profile.unset')); ?>

							</a>
							<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				<h3><?php echo e(__('profile.addNewSysadmin')); ?></h3>
				<form method="get" action="<?php echo e(\URL::to('/profilesetsysadmin/a/add')); ?>">
					<label><?php echo e(__('profile.email')); ?></label>
					<input type="text" name="value" />
					<button type="submit" class="btn btn-primary">
						<?php echo e(__('ok')); ?>

					</button>
				</form>
            </div>
   			<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </body>
</html>
<?php /**PATH /var/www/html/LaravelSocialite/resources/views/sysadmins.blade.php ENDPATH**/ ?>