<?php $__env->startSection('content'); ?>
<div>
	    	<?php echo $__env->make('popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            <div class="pageBody max-w-6xl mx-auto sm:px-6 lg:px-8">
           		<h2><?php echo e(env('APP_NAME')); ?></h2>	
            	<img src="/images/logo.png" class="logo" />
	            <div class="row">
	                <div class= "col-sm-3">
	                	<h2><?php echo e(__('project.filter')); ?></h2>
	                	<div id="skillsTree"></div>
	                </div>	
	                <div class= "col-sm-9" id="projectsTable">
	                	<h2><?php echo e(__('project.projects')); ?></h2>
						<table class="table table-bordered table-hover">
						    <thead>
						        <th></th>
						        <th>
						        	<a href="/projects?page=1&orderfield=projects.name">
						        	<?php echo e(__('project.name')); ?>

						        	<?php if($projects->orderField == 'projects.name'): ?>
						        		<?php if($projects->orderDir == 'ASC'): ?>
						        			<em class="fa fa-caret-down"></em>
						        		<?php else: ?>
						        			<em class="fa fa-caret-up"></em>
						        		<?php endif; ?>
						        	<?php endif; ?>
						        	</a>
						        </th>
						        <th>
						        	<a href="/projects?page=1&orderfield=projects.status">
						        	<?php echo e(__('project.status')); ?>

						        	<?php if($projects->orderField == 'projects.status'): ?>
						        		<?php if($projects->orderDir == 'ASC'): ?>
						        			<em class="fa fa-caret-down"></em>
						        		<?php else: ?>
						        			<em class="fa fa-caret-up"></em>
						        		<?php endif; ?>
						        	<?php endif; ?>
						        	</a>
						        </th>
						        <th>
						        	<a href="/projects?page=1&orderfield=projects.deadline">
						        	<?php echo e(__('project.deadline')); ?>

						        	<?php if($projects->orderField == 'projects.deadline'): ?>
						        		<?php if($projects->orderDir == 'ASC'): ?>
						        			<em class="fa fa-caret-down"></em>
						        		<?php else: ?>
						        			<em class="fa fa-caret-up"></em>
						        		<?php endif; ?>
						        	<?php endif; ?>
						        	</a>
						        </th>
						        <th>
						        	<a href="/projects?page=1&orderfield=skills">
						        	<?php echo e(__('project.skills')); ?>

						        	<?php if($projects->orderField == 'skills'): ?>
						        		<?php if($projects->orderDir == 'ASC'): ?>
						        			<em class="fa fa-caret-down"></em>
						        		<?php else: ?>
						        			<em class="fa fa-caret-up"></em>
						        		<?php endif; ?>
						        	<?php endif; ?>
						        	</a>
						        </th>
						        
						    </thead>
						    <tbody>
						        <?php if($projects->count() == 0): ?>
						        <tr>
						            <td colspan="5"><?php echo e(__('project.notrecords')); ?></td>
						        </tr>
						        <?php endif; ?>
						
						        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						        <tr>
						            <td><img class="avatar" src="<?php echo e($project->avatar); ?>" /></td>
						            <td><a href="/project/<?php echo e($project->id); ?>">
						            	<em class="fa fa-hand-point-right"></em>
						            	<?php echo e($project->name); ?>

						            	</a>
						            	<?php if($project->website != ''): ?> 
						            	<br />
						            	<a href="<?php echo e($project->website); ?>" target="_new"><?php echo e($project->website); ?></a>
						            	<?php endif; ?>
						            </td>
						            <td><?php echo e(__('project.'.$project->status)); ?></td>
						            <td><?php echo e($project->deadline); ?></td>
						            <td><?php echo e($project->skills); ?></td>
						        </tr>
						        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						    </tbody>
						</table>
						<?php echo e($projects->links()); ?>

						<p>
						    <?php echo e($projects->count()); ?> / <?php echo e($projects->total()); ?> 
						</p>
						<p class="buttons">
							<a class="btn btn-primary" href="/project/0">
								<em class="fa fa-plus-square"></em>
								<?php echo e(__('project.add')); ?>

							</a>						
						</p>
	                </div>
	            </div>
            </div>
		<script src="js/tree.js"></script>
        <script type="text/javascript">
        $(function() {
        	// JQuery onload

			function decodeEntities(encodedString) {
			  var textArea = document.createElement('textarea');
			  textArea.innerHTML = encodedString;
			  return textArea.value;
			}

        	// skill fa megjelenitő init
        	var skillTree = new Tree('#skillsTree', {
                		data: <?php echo $skillsTree; ?>,
                		closeDepth:10,
                		values: JSON.parse(decodeEntities("<?php echo e($projects->filter); ?>")),
                		onChange: function() {
                			console.log(this.values);
                			if (this.doRedirect) {
                				let s = JSON.stringify(this.values);
                				s = encodeURI(s.replaceAll(/\"/g,''));
                				window.setTimeout('location="/projects?page=1&filter='+s+'"',500);
                			}	
                		},	
                		loaded: function() {
                			this.doRedirect = true;
                		}	
                	});
                });	
         </script>              
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/c4hu-platform/resources/views/project-index-paging.blade.php ENDPATH**/ ?>