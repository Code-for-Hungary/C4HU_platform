<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
   	<?php echo $__env->make('htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <div id="app">
    	<div> 
    		<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    	</div>
    	<div>
        	<main class="pageBody py-4">
            	<?php echo $__env->yieldContent('content'); ?>
        	</main>
        </div>
        <div>
			<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>	
    </div>
</body>
</html>
<?php /**PATH /var/www/html/c4hu-platform/resources/views/layouts/app.blade.php ENDPATH**/ ?>