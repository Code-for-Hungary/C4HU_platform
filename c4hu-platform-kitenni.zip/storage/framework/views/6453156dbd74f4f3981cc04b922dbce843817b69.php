<?php $__env->startSection('content'); ?>
    <div class="loginForm">
        <form method="POST" action="<?php echo e(route('login')); ?>" id="frmLogin">
            <?php echo csrf_field(); ?>
            <div class="text-center">
                <a href="/" aria-label="Space">
                    <img class="mb-3 logo-image" src="<?php echo e(URL::to('images/logo.png')); ?>" alt="Logo" width="60" height="60">
                </a>
            </div>
            <div class="text-center mb-4">
	        	<h2><?php echo e(env('APP_NAME')); ?></h2>
                <h1 class="h3 mb-0"><?php echo e(__('login.PleaseSignIn')); ?></h1>
            </div>
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php endif; ?>
    
            
            <div class="js-form-message mb-3">
                <div class="js-focus-state input-group form">
                <div class="input-group-prepend form__prepend">
                    <span class="input-group-text form__text">
                    <i class="fa fa-envelope form__text-inner"></i> E-mail
                    </span>
                </div>
                <input type="email" class="form-control form__input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>"  placeholder="Email" autocomplete="email">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="fa fa-lock"></i> <?php echo e(__('login.Password')); ?>

                        </span>
                    </div>
                    <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"  
                    	placeholder="<?php echo e(__('login.Password')); ?>" autocomplete="new-password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-6">
                  <!-- Checkbox -->
                  <div class="custom-control custom-checkbox d-flex align-items-center text-muted">
                    <input class="custom-control-input"type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                    <label class="custom-control-label" for="remember">
                      <?php echo e(__('login.RememberMe')); ?>

                    </label>
                  </div>
                  <!-- End Checkbox -->
                </div>
            </div>
            
            <div class="form-group mb-3">
                <button type="submit" class="btn btn-primary login-btn btn-block"><?php echo e(__('login.Signup')); ?></button>
            </div>
            <div class="mb-12">
                <p class="text-muted"><?php echo e(__('login.NotSignin')); ?> <a href="<?php echo e(route('register')); ?>">
                	<?php echo e(__('login.Regist')); ?></a></p>
                <p class="text-muted">
                	<var onclick="jQuery('#frmLogin').attr('action','/forget-password'); jQuery('#frmLogin').submit();"
                		style="cursor:pointer">
                		<?php echo e(__('login.ForgetPassword')); ?></var></p>
            </div>
            
            <div class="or-seperator"><i><?php echo e(__('login.SocialLogin')); ?></i></div>
            <div class="row mx-gutters-2 mb-4">
                <div class="mb-12">
                    <a href="<?php echo e(route('login.google')); ?>">
                        <button type="button" class="btn btn-block btn-google">
                        	<em class="fa fa-google"></em>google
                        </button>
                    </a>
                    <a href="<?php echo e(route('login.facebook')); ?>">
                        <button type="button" class="btn btn-block btn-facebook">
                        	<em class="fa fa-facebook"></em>facebook
                        </button>
                    </a>
                    <a href="<?php echo e(route('login.github')); ?>">
                        <button type="button" class="btn btn-github">
                        	<em class="fa fa-github"></em>github
                        </button>
                    </a>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/c4hu-platform/resources/views/auth/login.blade.php ENDPATH**/ ?>