<?php $__env->startSection('content'); ?>
<div class="bugreport">
    <form method="POST" action="<?php echo e(\URL::to('/bugreportsend')); ?>" id="frmBugreport">
    	<h2><?php echo e(env('APP_NAME')); ?></h2>
    	<img src="/images/logo.png" class="logo" />
    	<h3><?php echo e(__('bugreport.reportForm')); ?></h3>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text">
                        <?php echo e(__('bugreport.description')); ?>

                    </span>
                </div>
                <textarea cols="80" rows="10" class="form-control" name="description"></textarea>  
            </div>
        </div>
        <div class="form-group">
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text">
                        <?php echo e(__('bugreport.taskInfo')); ?>

                    </span>
                </div>
                <textarea cols="80" rows="10" class="form-control" name="taskInfo">
                	<?php echo e(JSON_encode($taskInfo,JSON_PRETTY_PRINT)); ?>

                </textarea>  
                <br /><?php echo e(__('bugreport.help')); ?>

            </div>
        </div>
        <div class="form-group">
        	<button type="submit" class="btn btn-primary"><?php echo e(__('bugreport.send')); ?></button>
		</div>
    </form>
</div>
<?php $__env->stopSection(); ?>				
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/c4hu-platform/resources/views/bugreport.blade.php ENDPATH**/ ?>