<div class="footer">
	<div class="row">
		<div class="col-sm-6">
			<strong><em class="fa fa-lock"></em> GDPR</strong><br />
			<a href="<?php echo e(\URL::to('/textpage/policy1')); ?>">
				<?php echo e(__('footer.policy1')); ?>

			</a><br />
			<a href="<?php echo e(\URL::to('/textpage/policy2')); ?>">
				<?php echo e(__('footer.policy2')); ?>

			</a><br />
			<a href="<?php echo e(\URL::to('/textpage/policy3')); ?>">
				<?php echo e(__('footer.policy3')); ?>

			</a>
		</div>
		<div class="col-sm-6">
			<a href="<?php echo e(\URL::to('/textpage/impressum')); ?>">
				<em class="fa fa-info-circle"></em> <?php echo e(__('footer.impressum')); ?>

			</a><br />
			<a href="https://opensource.org/licenses/MIT" target="_new">
				<em class="fa fa-copyright"></em> <?php echo e(__('footer.licence')); ?>

			</a><br />
			<a href="https://github.com/Code-for-Hungary/fogadj-orokbe-egy-web-oldalt" target="_new">
				<em class="fa fa-code"></em> <?php echo e(__('footer.source')); ?>

			</a><br />
			<a href="<?php echo e(\URL::to('/bugreportform')); ?>">
				<em class="fa fa-bug"></em> <?php echo e(__('footer.bugreport')); ?>

			</a><br />
		
		</div>
	</div>
</div>
<?php echo $__env->make('cookieConsent::index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div><pre>
<?php 
// task info tárolása a sessionba a hibajelentéshez
request()->session()->forget('taskInfo');
$taskInfo = new \stdClass();
$taskInfo->REQUEST_URI = $_SERVER['REQUEST_URI'];
$taskInfo->REQUEST_METHOD = $_SERVER['REQUEST_METHOD'];
$taskInfo->HTTP_USER_AGENT = $_SERVER['HTTP_USER_AGENT'];
$taskInfo->REQUESTS = request()->all();
$taskInfo->SESSIONS = request()->session()->all();
$taskInfo->USER = \Auth::user();
request()->session()->put('taskInfo',$taskInfo);
?>
</pre></div><?php /**PATH /var/www/html/LaravelSocialite/resources/views/footer.blade.php ENDPATH**/ ?>