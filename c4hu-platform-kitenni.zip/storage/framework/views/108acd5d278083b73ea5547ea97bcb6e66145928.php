<h2><?php echo e(__('emailverify.mailTitle')); ?></h2>
<p><?php echo e(__('emailverify.mailText')); ?></p>
<p><a href="<?php echo e($url); ?>"><?php echo e($url); ?></a></p>

<?php /**PATH /var/www/html/LaravelSocialite/resources/views/emailverify_mailbody.blade.php ENDPATH**/ ?>