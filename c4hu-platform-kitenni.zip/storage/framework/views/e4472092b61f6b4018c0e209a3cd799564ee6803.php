<?php $__env->startSection('content'); ?>
<div>
	    	<?php echo $__env->make('popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            <div class="pageBody max-w-6xl mx-auto sm:px-6 lg:px-8">
           		<h2><?php echo e(env('APP_NAME')); ?></h2>	
            	<img src="/images/logo.png" class="logo" />
				<?php if(count($errors) > 0): ?>
				   <div class = "alert alert-danger">
				      <ul>
				         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <li><?php echo e(__('profile.'.$error)); ?></li>
				         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </ul>
				   </div>
				<?php endif; ?>            
            	<ul class="nav nav-tabs">
					<li class="active">
						<a href="#"><?php echo e(__('profile.info')); ?></a>
					</li>
  					<li>
  						<a href="<?php echo e(\URL::to('/profileprojects/'.$profile->id)); ?>"><?php echo e(__('profile.linkedProjects')); ?></a>
  					</li>
				</ul>
                <div class="profileForm">
                	<form class="form">
		            	<h2><?php echo e(env('APP_NAME')); ?></h2>
        		    	<img src="/images/logo.png" class="logo" />
		            	<h3><?php echo e(__('profile.profile')); ?></h3>
	                    <div class="form-group">
	                    	<?php echo e($profile->name); ?>

	                    	<img class="bigAvatar" src="<?php echo e($profile->avatar); ?>" style="float:right" />
						</div>		            	
	                    <div class="form-group">
	                    	<?php if($profile->sysadmin == 1): ?>
	                    	<strong></strong><?php echo e(__('profile.sysadmin')); ?></strong>
	                    	<?php endif; ?>
						</div>		            	

	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.voluntary')); ?>

                                    </span>
	                                <?php if($profile->voluntary == 1): ?> 
    	                            <input type="checkbox" disabled="disabled" name="voluntary" checked="checked" value="1"/>
        	                        <?php else: ?>
            	                    <input type="checkbox" disabled="disabled" name="voluntary" value="1" />
                	                <?php endif; ?>
                                </div>
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.project_owner')); ?>

                                    </span>
	                                <?php if($profile->project_owner == 1): ?>
    	                            <input type="checkbox" disabled="disabled" name="project_owner" checked="checked" value="1"  />
        	                        <?php else: ?>
            	                    <input type="checkbox" disabled="disabled" name="project_owner" value="1" />
                	                <?php endif; ?>
                                </div>
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.publicinfo')); ?>

                                    </span>
                                </div>
                                <textarea readonly="readonly" cols="80" rows="10" class="form-control" name="publicinfo"><?php echo e($profile->publicinfo); ?></textarea>  
                            </div>
                        </div>
                        <div class="skillsBlock">
                        	<h3> <?php echo e(__('profile.skills')); ?></h3>
                        	<?php $__currentLoopData = $profile->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        		<p><?php echo e($skill->name); ?> <?php echo e($skill->level); ?></p>
                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                </div>
	                    <div class="form-group">
							<a href="/email" class="btn bt-secondary">
								<em class="fa fa-envelope"></em>
								<?php echo e(__('profile.sendEmail')); ?>

							</a>
	                    	<a class="btn btn-primary" id="btnBack"
	                    		href="<?php echo e(url()->previous()); ?>">
	                    		<em class="fa fa-undo"></em>
	                    		<?php echo e(__('profile.back')); ?>

	                    	</a>
						</div>
                    </form>
                    <p>Saját adataidat a "profil" menüpontban módosíthatod.</p>
                </div>
            </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/c4hu-platform/resources/views/profileshow.blade.php ENDPATH**/ ?>