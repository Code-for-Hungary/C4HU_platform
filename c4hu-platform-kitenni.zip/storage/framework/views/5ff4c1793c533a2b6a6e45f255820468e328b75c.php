<pre><code>
<?php echo e($description); ?>


<?php echo e($taskInfo); ?>


</code></pre>

<?php /**PATH /var/www/html/LaravelSocialite/resources/views/bugreport_mail.blade.php ENDPATH**/ ?>