<?php 
if (!isset($popupYesNo)) {
    $popupYesNo = 0;
}
if (!isset($popupYesDanger)) {
    $popupYesDanger = 0;
}
?>
<div id="popup">
        <div class="modal-container">
            <div class="modal-header">
                <button type="button" class="close" onclick="$('#popup').hide(); ">
                    &times;</button> 
                    <h3 class="modal-title"><?php echo e($popupHeader ?? ''); ?></h3>
            </div>
            <div class="modal-body">
                <P id="popupBody"><?php echo e($popupBody ?? ''); ?></P>
                <p id="popupButtons">
                <?php if($popupYesNo == 1): ?> 
                    <a href="<?php echo e($popupYesUrl ?? ''); ?>" class="btn btn-primary"><?php echo e(__('yes')); ?></a>&nbsp;
                    <a href="<?php echo e($popupNoUrl ?? ''); ?>" class="btn btn-secondary"><?php echo e(__('no')); ?></a>
                <?php else: ?>    
                    <?php if($popupYesDanger == 1): ?> 
                        <a href="<?php echo e($popupYesUrl ?? ''); ?>" class="btn btn-danger"><?php echo e(__('yes')); ?></a>&nbsp;
                        <a href="<?php echo e($popupNoUrl ?? ''); ?>" class="btn btn-secondary"><?php echo e(__('no')); ?></a>
                    <?php else: ?> 
                        <button type="button" class="btn btn-danger" onclick="$('#popup').hide();">
                        <?php echo e(__('ok')); ?></button>
                    <?php endif; ?>
                <?php endif; ?>    
                </p>
            </div>
        </div>
</div>
<?php /**PATH /var/www/html/c4hu-platform/resources/views/popup.blade.php ENDPATH**/ ?>