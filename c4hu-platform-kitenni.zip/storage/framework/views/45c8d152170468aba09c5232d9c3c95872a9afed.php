<?php $__env->startSection('content'); ?>
<div>
            <div class="pageBody max-w-6xl mx-auto sm:px-6 lg:px-8">
                <div class="emailForm">
                	<h2><?php echo e(__('email.sendEmail')); ?></h2>
                	<form method="POST" action="<?php echo e(\URL::to('/email')); ?>" id="frmEmail">
		            	<h3><?php echo e(__('project.project')); ?></h3>
		            	<p><?php echo e(__('email.to')); ?>: <?php echo e($toName); ?></p>
		            	<p><?php echo e(__('email.from')); ?>: <?php echo e(\Auth::user()->name); ?></p>
                        <?php echo csrf_field(); ?>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('email.subject')); ?>

                                    </span>
                                </div>
                                <input type="text" class="form-control" name="subject" 
                                size="80" value="" />
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('email.body')); ?>

                                    </span>
                                </div>
                                <textarea cols="80" rows="10" class="form-control" name="body"></textarea>  
                            </div>
                        </div>

	                    <div class="form-group">
	                    	<button class="btn btn-primary" id="btnSave">
	                    		<em class="fa fa-check"></em><?php echo e(__('email.send')); ?>

	                    	</button>
	                    	<a class="btn btn-secondary") href="<?php echo e(url()->previous()); ?>">
	                    		<em class="fa fa-undo"></em>
	                    		<?php echo e(__('email.back')); ?>

	                    	</a>
						</div>
                    </form>
                </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/c4hu-platform/resources/views/emailform.blade.php ENDPATH**/ ?>