<?php $__env->startSection('content'); ?>
<div class="pageBody construction text-center">
   	<p><img src="images/construction.png" style="height:200px" /></p>
   	<p><?php echo e(__('underConstruction')); ?></p>
   	<p><a class="btn btn-primary" href="<?php echo e(url()->previous()); ?>">Back</a></p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/c4hu-platform/resources/views/construction.blade.php ENDPATH**/ ?>