<div>
<pre>
<code>
<?php echo e($body); ?>

</code>
</pre>
</div>
<p>Feladó: <?php echo e($fromName); ?>  <?php echo e($fromEmail); ?>


<?php /**PATH /var/www/html/c4hu-platform/resources/views/emailmsg.blade.php ENDPATH**/ ?>