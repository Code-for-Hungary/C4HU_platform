<?php $__env->startSection('content'); ?>
<div>
        <div>
            <div class="pageBody">
            <?php include $fname; ?>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/c4hu-platform/resources/views/textpage.blade.php ENDPATH**/ ?>