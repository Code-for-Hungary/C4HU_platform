<?php $__env->startSection('content'); ?>
<div>
	    	<?php echo $__env->make('popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            <div class="pageBody max-w-6xl mx-auto sm:px-6 lg:px-8">
           		<h2><?php echo e(env('APP_NAME')); ?></h2>	
            	<img src="/images/logo.png" class="logo" />
				<?php if(count($errors) > 0): ?>
				   <div class = "alert alert-danger">
				      <ul>
				         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <li><?php echo e(__('project.'.$error)); ?></li>
				         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </ul>
				   </div>
				<?php endif; ?>            
            	<ul class="nav nav-tabs">
					<li class="active">
						<a href="#"><?php echo e(__('project.info')); ?></a>
					</li>
  					<li>
  						<a href="<?php echo e(\URL::to('/contributors/'.$project->id)); ?>"><?php echo e(__('project.contributors')); ?></a>
  					</li>
				</ul>
                <div class="projectShow">
                	<form method="POST" action="<?php echo e(\URL::to('/project')); ?>" id="frmProject">
		            	<h3><?php echo e(__('project.project')); ?></h3>
	                    <div class="form-group">
                            <img class="avatar" src="<?php echo e($project->avatar); ?>" />&nbsp;
                            <label><?php echo e(__('project.name')); ?></label>:&nbsp;
                            <?php echo e($project->name); ?>

                        </div>
	                    <div class="form-group">
	                    	<label><?php echo e(__('project.ownerUser')); ?></label>:&nbsp;
	                    	<img class="avatar" src="<?php echo e($project->user_avatar); ?>" />&nbsp; 
	                    	<?php echo e($project->user_name); ?>

						</div>                        
	                    <div class="form-group">
                            <div class="input-group">
                                <label><?php echo e(__('project.organisation')); ?></label>:&nbsp;
                                <?php echo e($project->organisation); ?>

                            </div>
                        </div>
	                    <div class="form-group">
                                <label><?php echo e(__('project.website')); ?></label>:&nbsp;
                                <a href="$project->website" target="_new"><?php echo e($project->website); ?></a>
                        </div>
	                    <div class="form-group">
                                <label><?php echo e(__('project.deadline')); ?></label>:&nbsp;
                                <?php echo e($project->deadline); ?>

                        </div>
	                    <div class="form-group">
                                <label><?php echo e(__('project.status')); ?></label>:&nbsp;
                                <?php echo e($project->status); ?>

                        </div>

	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <label><?php echo e(__('project.description')); ?></label>
                                    </span>
                                </div>
                                <textarea readonly="readonly" cols="80" rows="10" class="form-control" name="description"><?php echo e($project->description); ?></textarea>  
                            </div>
                        </div>

                        <div class="skillsBlock">
                            <h3><?php echo e(__('project.skills')); ?></h3>
							<?php $__currentLoopData = $project->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                        		<?php echo e($skill->name); ?>

                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        	<br /><br />
                        </div>	
	                    <div class="form-group">
	                    	<?php if(\Auth::user()): ?>
	                    	<a class="btn btn-secondary" href="/contributoradd/<?php echo e($project->id); ?>">
	                    		<em class="fa fa-hand-paper"></em>
	                    		<?php echo e(__('project.aspirant')); ?>

	                    	</a>
	                    	<a class="btn btn-secondary" href="/email">
	                    		<em class="fa fa-envelope"></em>
	                    		<?php echo e(__('project.sendEmail')); ?>

	                    	</a>
	                    	<?php endif; ?>
	                    	<a class="btn btn-primary" href="<?php echo e(url()->previous()); ?>">
	                    		<em class="fa fa-undo"></em>
	                    		<?php echo e(__('project.back')); ?>

	                    	</a>
						</div>
                    </form>
                </div>
            </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/c4hu-platform/resources/views/projectshow.blade.php ENDPATH**/ ?>