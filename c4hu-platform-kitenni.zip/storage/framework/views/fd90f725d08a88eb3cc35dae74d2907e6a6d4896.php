<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
    	<?php echo $__env->make('htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="antialiased">
        <div id="app" class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center sm:pt-0">
	    	<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	    	
            <div class="pageBody max-w-6xl mx-auto sm:px-6 lg:px-8">
                <div class="loginForm">
                    <form method="POST" action="<?php echo e(\URL::to('/bugreportsend')); ?>" id="frmBugreport">
		            	<h2><?php echo e(env('APP_NAME')); ?></h2>
        		    	<img src="/images/logo.png" class="logo" />
		            	<h3><?php echo e(__('bugreport.reportForm')); ?></h3>
                        <?php echo csrf_field(); ?>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('bugreport.description')); ?>

                                    </span>
                                </div>
                                <textarea cols="80" rows="10" class="form-control" name="description"></textarea>  
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('bugreport.taskInfo')); ?>

                                    </span>
                                </div>
                                <textarea cols="80" rows="10" class="form-control" name="taskInfo">
                                	<?php echo e(JSON_encode($taskInfo,JSON_PRETTY_PRINT)); ?>

                                </textarea>  
                                <br /><?php echo e(__('bugreport.help')); ?>

                            </div>
                        </div>
	                    <div class="form-group">
	                    	<button type="submit" class="btn btn-primary"><?php echo e(__('bugreport.send')); ?></button>
						</div>
                    </form>
                </div>
            </div>
   			<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </body>
</html>
<?php /**PATH /var/www/html/LaravelSocialite/resources/views/bugreport.blade.php ENDPATH**/ ?>