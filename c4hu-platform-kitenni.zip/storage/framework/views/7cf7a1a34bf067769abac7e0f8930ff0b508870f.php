<?php $__env->startSection('content'); ?>
<div>
            <div class="pageBody max-w-6xl mx-auto sm:px-6 lg:px-8">
		    	<?php echo $__env->make('popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
           		<h2><?php echo e(env('APP_NAME')); ?></h2>	
            	<img src="/images/logo.png" class="logo" />
				<?php if(count($errors) > 0): ?>
				   <div class = "alert alert-danger">
				      <ul>
				         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <li><?php echo e(__('profile.'.$error)); ?></li>
				         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </ul>
				   </div>
				<?php endif; ?>            
            	<ul class="nav nav-tabs">
					<li class="active">
						<a href="#"><?php echo e(__('profile.info')); ?></a>
					</li>
  					<li>
  						<a href="<?php echo e(\URL::to('/profileprojects/'.\Auth::user()->id)); ?>"><?php echo e(__('profile.linkedProjects')); ?></a>
  					</li>
				</ul>
                <div class="profileForm">
                	<form method="POST" action="<?php echo e(\URL::to('/profilesave')); ?>" id="frmProfile">
		            	<h3><?php echo e(__('profile.profile')); ?></h3>
	                    <div class="form-group">
	                    	<?php echo e(\Auth::user()->name); ?>

	                    	<img class="bigAvatar" src="<?php echo e(\Auth::user()->avatar); ?>" style="float:right" />
						</div>		            	
	                    <div class="form-group">
	                    	<?php if($sysadmin == 1): ?>
	                    	<strong></strong><?php echo e(__('profile.sysadmin')); ?></strong>
	                    	<?php endif; ?>
						</div>		            	
                        <?php echo csrf_field(); ?>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.password')); ?>

                                    </span>
                                </div>
                                <input type="password" class="form-control" name="password" 
                                size="80" value="" />
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.password_repeat')); ?>

                                    </span>
                                </div>
                                <input type="password" class="form-control" name="password2" 
                                size="80" value="" />
                            </div>
                        </div>
	                    <div class="form-group">
	                    	<?php echo e(__('profile.passwordhelp')); ?>

                        </div>


	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.avatar')); ?>

                                    </span>
                                </div>
                                <input type="text" class="form-control" name="avatar" 
                                size="80" value="<?php echo e(\Auth::user()->avatar); ?>" />
                                <br /><?php echo e(__('profile.avatarhelp')); ?>

                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.voluntary')); ?>

                                    </span>
	                                <?php if($voluntary == 1): ?> 
    	                            <input type="checkbox" name="voluntary" checked="checked" value="1"/>
        	                        <?php else: ?>
            	                    <input type="checkbox" name="voluntary" value="1" />
                	                <?php endif; ?>
                                </div>
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.project_owner')); ?>

                                    </span>
	                                <?php if($project_owner == 1): ?>
    	                            <input type="checkbox" name="project_owner" checked="checked" value="1"  />
        	                        <?php else: ?>
            	                    <input type="checkbox" name="project_owner" value="1" />
                	                <?php endif; ?>
                                </div>
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.publicinfo')); ?>

                                    </span>
                                </div>
                                <textarea cols="80" rows="10" class="form-control" name="publicinfo"><?php echo e($publicinfo); ?></textarea>  
                            </div>
                        </div>
                        <div class="skillsBlock">
			                <div class="row">
				                <div class= "col-sm-6"><?php echo e(__('profile.skills')); ?></div>
				                <div class= "col-sm-6"><?php echo e(__('profile.skillLevels')); ?></div>
			                </div>
			                <div class="row">
				                <div class= "col-sm-6" id="skillsTree"></div>
				                <div class= "col-sm-6" id="skillLevels"></div>
			                </div>
		                </div>
	                    <div class="form-group">
	                    	<button type="button" class="btn btn-primary" id="btnSave">
	                    		<?php echo e(__('profile.save')); ?>

	                    	</button>
						</div>
	                    <div class="form-group">
	                    	<?php if($sysadmin == 1): ?>
	                    	<a class="btn btn-secondary" href="<?php echo e(\URL::to('profilesysadmins')); ?>">
	                    		<?php echo e(__('profile.sysadmins')); ?></a>
	                    	<?php else: ?>
	                    	<a  class="btn btn-danger" href="<?php echo e(\URL::to('profiledel')); ?>">
	                    		<?php echo e(__('profile.delete')); ?></a>
	                    	<?php endif; ?>
						</div>
	                    <div class="form-group">
	                    	<?php echo e(__('profile.help')); ?>

						</div>	
						<input type="hidden" id="skills" name="skills" value='<?php echo $skills; ?>' />					
                    </form>
                </div>
                <!-- skillLevel template -->
                <div style="display:none">
               		<p id="skillLevelTemplate">
		                	<label style="width:50%; text-align:right"></label>
		                	<select>
		                		<option value="student"><?php echo e(__('profile.student')); ?></option>
		                		<option value="junior"><?php echo e(__('profile.junior')); ?></option>
		                		<option value="senior"><?php echo e(__('profile.senior')); ?></option>
		                		<option value="mentor"><?php echo e(__('profile.mentor')); ?></option>
		                	</select>
               		</p> 
               	</div>
            </div>
        <script src="js/tree.js"></script>
        <script type="text/javascript">
        $(function() {
        	// JQuery onload
        	
			// {az aktuális user képességei skillId:skillLevel, ....}
        	var skills = JSON.parse($('#skills').val());
        	
       		/* 
       		* skilss objektum kialakitása a skillTre és aképernyőn lévő adatokból,
       		* beirása a rejtett input mezőbe
       		*/
        	setSkillsFromScreen = function() {
        		if (skillTree) {
					skills = {};
				    for(i = 0; i < skillTree.values.length; i++) {
				    	let value = skillTree.values[i];
				    	if ($('#level_'+value+' select').val()) {
				    		skills[value] = $('#level_'+value+' select').val();
				    	}
					}			
					$('#skills').val(JSON.stringify(skills));
				}
        	};
        	
			/**
			* btnSave click - skills rejtett input mező feltöltése, form submit
			*/
        	$('#btnSave').click(function() {
					setSkillsFromScreen();
					$('#frmProfile').submit();
        	});
        	
			// skills objektumból values array-t képez        	
        	let valuesArray = [];
		    for (const [key, value] of Object.entries(<?php echo $skills; ?>)) {
		    	valuesArray.push(key);
        	}

        	// skill fa megjelenitő init
        	var skillTree = new Tree('#skillsTree', {
                		data: <?php echo $skillsTree; ?>,
                		closeDepth:1,
                		values: valuesArray,
                		onChange: function() {
						    var i = 0;
					    	setSkillsFromScreen();
						    $('#skillLevels').html('');
						    for(i = 0; i < this.values.length; i++) {
						    	let p = $('#skillLevelTemplate').clone();
						    	p.attr('id','level_'+this.values[i]);
						    	p.css('display','block');
						    	$('#skillLevels').append(p);
						    	let node = this.nodesById[this.values[i]];
						    	$('#level_'+this.values[i]+' label').html(node.text);
						    } 
						    for (const [key, value] of Object.entries(skills)) {
								if ($('#level_'+key)) {
									$('#level_'+key+' select').val(value);								
								}									  
							}
  						},
                	});
                });	
         </script>       	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/c4hu-platform/resources/views/profile.blade.php ENDPATH**/ ?>