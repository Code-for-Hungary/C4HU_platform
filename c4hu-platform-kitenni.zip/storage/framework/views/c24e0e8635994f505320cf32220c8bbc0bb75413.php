<?php $__env->startSection('content'); ?><!DOCTYPE html>
	    	<?php echo $__env->make('popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php 
// WORK
$mentor = 1;
?>
            <div class="pageBody max-w-6xl mx-auto sm:px-6 lg:px-8">
                <div class="profileForm">
                	<a href="" class="btn btn-secondary">
						<em class="fa fa-hammer"></em> <?php echo e(__('profile.works_and evaluations')); ?>                	
                	</a>
                    <form method="POST" action="<?php echo e(\URL::to('/profilesave')); ?>" id="frmProfile">
		            	<h2><?php echo e(env('APP_NAME')); ?></h2>
        		    	<img src="/images/logo.png" class="logo" />
		            	<h3><?php echo e(__('profile.profile')); ?></h3>
	                    <div class="form-group">
	                    	<strong><?php echo e(\Auth::user()->name); ?></strong>
						</div>		            	
	                    <div class="form-group">
	                    	<?php if($sysadmin == 1): ?>
	                    	<strong></strong><?php echo e(__('profile.sysadmin')); ?></strong>
	                    	<?php endif; ?>
						</div>		            	
        		    	<img src="<?php echo e(\Auth::user()->avatar); ?>" class="avatar" style="float:right" />
                        <?php echo csrf_field(); ?>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.email')); ?>

                                    </span>
                                </div>
                                <input type="text" class="form-control" name="email" 
                                size="80" value="" value=" <?php echo e(\Auth::user()->email); ?>"/>
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.password')); ?>

                                    </span>
                                </div>
                                <input type="password" class="form-control" name="password" 
                                size="80" value="" />
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.password_repeat')); ?>

                                    </span>
                                </div>
                                <input type="password" class="form-control" name="password2" 
                                size="80" value="" />
                                <br /><?php echo e(__('profile.passwordhelp')); ?>

                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.realname')); ?>

                                    </span>
                                </div>
                                <input type="text" class="form-control" name="realname" 
                                size="80" value="" />
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.phone')); ?>

                                    </span>
                                </div>
                                <input type="text" class="form-control" name="phone" 
                                size="80" value="" />
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.location')); ?>

                                    </span>
                                </div>
                                <?php echo e(__('profile.zip')); ?>

                                <input type="text" name="zip" 
                                size="4" value="" />
                                <?php echo e(__('profile.city')); ?>

                                <input type="text" name="city" 
                                size="44" value="" />
                                
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.avatar')); ?>

                                    </span>
                                </div>
                                <input type="text" class="form-control" name="avatar" 
                                size="80" value="<?php echo e(\Auth::user()->avatar); ?>" />
                                <br /><?php echo e(__('profile.avatarhelp')); ?>

                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.voluntary')); ?>

                                    </span>
	                                <?php if($voluntary == 1): ?> 
    	                            <input type="checkbox" name="voluntary" checked="checked" value="1"/>
        	                        <?php else: ?>
            	                    <input type="checkbox" name="voluntary" value="1" />
                	                <?php endif; ?>

                	                &nbsp;&nbsp;
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.web_site_owner')); ?>

                                    </span>
	                                <?php if($web_site_owner == 1): ?>
    	                            <input type="checkbox" name="web_site_owner" checked="checked" value="1"  />
        	                        <?php else: ?>
            	                    <input type="checkbox" name="web_site_owner" value="1" />
                	                <?php endif; ?>
                	                
                	                &nbsp;&nbsp;
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.mentor')); ?>

                                    </span>
	                                <?php if($mentor == 1): ?>
    	                            <input type="checkbox" name="mentor" checked="checked" value="1"  />
        	                        <?php else: ?>
            	                    <input type="checkbox" name="mentor" value="1" />
                	                <?php endif; ?>
                	                
                                </div>
                            </div>
                        </div>
                        <div class="details">
    	                    <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <?php echo e(__('profile.profession')); ?>

                                        </span>
                                    </div>
                                    <input type="text" class="form-control" name="profession" 
                                    size="80" value="" />
                                </div>
                            </div>
    	                    <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <?php echo e(__('profile.period')); ?>

                                        </span>
                                    </div>
                                    <input type="number"  name="period" 
                                    size="3" value="" /><?php echo e(__('profile.monts')); ?>

                                    <input type="number"  name="hours" 
                                    size="3" value="" /><?php echo e(__('profile.hours')); ?>

                                    
                                </div>
                            </div>
                            <div id="abilitys">
                            <h3><?php echo e(__('profile.abilitys')); ?></h3>
                        	<div class="ability" id="ability0">
                        		<select name="undertake0" id="undertake0" 
                        			onchange="undertakeChange(event)">
                        			<option value="organizer"><?php echo e(__('profile.organizer')); ?></option>
                        			<option value="hr"><?php echo e(__('profile.hr')); ?></option>
                        			<option value="communicator"><?php echo e(__('profile.comminicator')); ?></option>
                        			<option value="logistic"><?php echo e(__('profile.logistic')); ?></option>
                        			<option value="designer"><?php echo e(__('profile.designer')); ?></option>
                        			<option value="documentor"><?php echo e(__('profile.documentor')); ?></option>
                        			<option value="piar"><?php echo e(__('profile.piar')); ?></option>
                        			<option value="eventmanager"><?php echo e(__('profile.eventmanager')); ?></option>
                        			<option value="ux"><?php echo e(__('profile.ux')); ?></option>
                        			<option value="archítect"><?php echo e(__('profile.archytect')); ?></option>
                        			<option value="test"><?php echo e(__('profile.test')); ?></option>
                        			<option value="backend"><?php echo e(__('profile.backend')); ?></option>
                        			<option value="database"><?php echo e(__('profile.database')); ?></option>
                        			<option value="frontend"><?php echo e(__('profile.frontend')); ?></option>
                        			<option value="server"><?php echo e(__('profile.server')); ?></option>
                        			<option value="mobile"><?php echo e(__('profile.mobile')); ?></option>
                        			<option value="other"><?php echo e(__('profile.other')); ?></option>
                        		</select>
                        		<select name="detail0" id="detail0">
                        			<option value=""></option>
                        		</select>
                        		<select name="level0" id="level0">
                        			<option value="interested"><?php echo e(__('profile.interested')); ?></option>
                        			<option value="student"><?php echo e(__('profile.student')); ?></option>
                        			<option value="junior"><?php echo e(__('profile.junior')); ?></option>
                        			<option value="senior"><?php echo e(__('profile.senior')); ?></option>
                        			<option value="mentor"><?php echo e(__('profile.mentor')); ?></option>
                        		</select>
                        		<button type="button" class="btn btn-secondary"
                        			id="del0" onclick="delAbility(event)">-</button>
                        	</div><!-- ability{n} -->
                        	</div><!--  #abilitys --> 
                       		<button type="button" class="btn btn-secondary"
                        			id="add0" onclick="addAbility(event)">+</button>
                        </div><!-- .details -->
                        
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('profile.publicinfo')); ?>

                                    </span>
                                </div>
                                <textarea cols="80" rows="10" class="form-control" name="publicinfo"><?php echo e($publicinfo); ?></textarea>  
                            </div>
                        </div>
	                    <div class="form-group">
	                    	<button type="submit" class="btn btn-primary">
	                    		<em class="fa fa-check"></em> <?php echo e(__('profile.save')); ?></button>
						</div>
	                    <div class="form-group">
	                    	<?php if($sysadmin == 1): ?>
	                    	<a class="btn btn-secondary" href="<?php echo e(\URL::to('profilesysadmins')); ?>">
	                    		<em class="fa fa-chess-king"></em> <?php echo e(__('profile.sysadmins')); ?></a>
	                    	<?php else: ?>
	                    	<button type="button"  class="btn btn-danger" 
	                    		onclick="$('#popup').show();">
	                    		<em class="fa fa-times"></em> <?php echo e(__('profile.delete')); ?></button>
	                    	<?php endif; ?>
						</div>
	                    <div class="form-group">
	                    	<?php echo e(__('profile.help')); ?>

						</div>						
                    </form>
                </div>
                
                <script type="text/javascript">
                    var maxId = 0;
                    var idCount = 1;
                    // define details
                    var details = {
                    	'backend': ['python','Node js','PHP','C#','Java','Rubby','Scala','Go'],
                    	'database': ['MySQL', 'PostgradeSQL', 'NoSQL', 'SQLServer', 'Meteor'],
                    	'server': ['Apache','Amazon','WEB service','Docker','DNS','Digital Ocean'],
                    	'frontend':['HTML','CSS','Javascript','Gulp','SASS','MV*','React','Angular','Vue','Ember','Webpack'],
						'mobile':['Swift','C#','Ionic','React','Native','Java','C','C++']                    	
                    };
                    /**
                    * undertake change; set details options
                    * @param  event   event.targat undertake select
                    */
                	function undertakeChange(event) {
                		// a target.id alapján modosítani kell a hozzá tartozó
                		// detail opcióit
                		console.log('change');
                		console.log(event);
                   		let target = event.target;
                   		let oldId = parseInt(target.id.substring(9,100));
                   		let value = target.options[target.selectedIndex].value;
                   		let lc = document.getElementById('detail'+oldId);
                   		while (lc.length > 0) {
                   			lc.remove(0);
                   		}
                   		if (details[value]) {
                   			for (var i=0; i<details[value].length; i++) {
                   				opt = document.createElement('option');
                   				opt.value = details[value][i];
                   				opt.text = details[value][i];
                   				lc.add(opt);
                   			}
                   		}
                	}
                	/**
                	* btn click hidde abbylity division and set disable form controls
                    * @param  event   event.targat del button
                	*/
                	function delAbility(event) {
                		// a target.id -ből megállapitható számu ability div -et láthatatlanná
                		// teszi, és a selecteket pedig disabled -é
                		if (idCount > 1) {
                    		let target = event.target;
                    		let oldId = parseInt(target.id.substring(3,100));
                    		let oldDiv = document.getElementById('ability'+oldId);
                    		oldDiv.childNodes[1].disabled = 'disabled';
                    		oldDiv.childNodes[3].disabled = 'disabled';
                    		oldDiv.childNodes[5].disabled = 'disabled';
                    		oldDiv.style.display = 'none';
                    		idCount = idCount - 1;
                		}
                	}
                	/**
                	* btn click, add new ability division
                    * @param  event   event.targat add button
                	*/
                	function addAbility(event) {
                		let target = event.target;
                		let oldId = 0;
                		let newId = maxId + 1;
                		let oldDiv = document.getElementById('ability'+oldId);
                		let newDiv = oldDiv.cloneNode(true);
                		newDiv.id = 'ability'+newId;
                		newDiv.childNodes[1].id = 'undertake'+newId;
                		newDiv.childNodes[1].name = 'undertake'+newId;
                		newDiv.childNodes[1].disabled = '';
                		newDiv.childNodes[3].id = 'detail'+newId;
                		newDiv.childNodes[3].name = 'detail'+newId;
                		newDiv.childNodes[3].disabled = '';
                		newDiv.childNodes[5].id = 'level'+newId;
                		newDiv.childNodes[5].name = 'detail'+newId;
                		newDiv.childNodes[5].disabled = '';
                		newDiv.childNodes[7].id = 'del'+newId;
                		newDiv.style.display = 'block';
                		document.getElementById('abilitys').appendChild(newDiv);
                		maxId = newId;
                		idCount = idCount + 1;
                	}
                	/**
                	* set select dom element value
                	* @param  string select dom element id
                	* @param  string value
                	*/
                	function setSelect(id,value) {
                		let lc = document.getElementById(id);
                		let i = 0;
                        for (i=0; i < lc.length; i++) {
                            if (lc.options[i].value == value) {
                                lc.selectedIndex = i;
                            }
                        }                		
                	}
                	/**
                	* set abiliity divisin values
                	* @param  integer id
                	* @param  string undertake
                	* @param  string detail
                	* @param  string level
                	*/
                	function setAbility(id, undertake, detail, level) {
                		if (id > 0) {
                			maxId = id - 1;
                			addAbility({});
                		}
                		setSelect('undertake'+id,undertake);
                		let event = {};
                		event.target = document.getElementById('undertake'+id);
                		undertakeChange(event); 
                		setSelect('detail'+id,detail);
                		setSelect('level'+id,level);
                	}
                	
                	
                	// TEST
                	setAbility(3, 'logistic','','senior');
                </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/LaravelSocialite/resources/views/profile.blade.php ENDPATH**/ ?>