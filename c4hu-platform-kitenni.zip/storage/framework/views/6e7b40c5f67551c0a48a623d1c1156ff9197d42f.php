<?php $__env->startSection('content'); ?>
<div>
aaaaaaaaaaaaaaaaaaa
	    	<?php echo $__env->make('popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            <div class="pageBody max-w-6xl mx-auto sm:px-6 lg:px-8">
           		<h2><?php echo e(env('APP_NAME')); ?></h2>	
            	<img src="/images/logo.png" class="logo" />
				<?php if(count($errors) > 0): ?>
				   <div class = "alert alert-danger">
				      <ul>
				         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <li><?php echo e(__('contributor.'.$error)); ?></li>
				         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </ul>
				   </div>
				<?php endif; ?>        
                <div class="contributorShow">
                	<form method="POST" action="<?php echo e(\URL::to('/contributor')); ?>" id="frmContributor">
		            	<h3><?php echo e(__('contributor.project')); ?></h3>
	                    <div class="form-group">
                            <img class="avatar" src="<?php echo e($contributor->project_avatar); ?>" />&nbsp;
                            <?php echo e($contributor->project_name); ?>

                        </div>
	                    <div class="form-group">
                                <label><?php echo e(__('contributor.status')); ?></label>:&nbsp;
                                <?php echo e(__('contributor.'.$contributor->project_status)); ?>

                        </div>
                        <h4><?php echo e(__('contributor.contributor')); ?></h4>
	                    <div class="form-group">
	                    	<img class="avatar" src="<?php echo e($contributor->user_avatar); ?>" />&nbsp; 
	                    	<?php echo e($contributor->user_name); ?>&nbsp;<?php echo e(__('contributor.'.$contributor->status)); ?>

						</div>                        
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <label><?php echo e(__('contributor.description')); ?></label>
                                    </span>
                                </div>
                                <textarea readonly="readonly" cols="80" rows="5" class="form-control" name="description"><?php echo e($contributor->description); ?></textarea>  
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <label><?php echo e(__('contributor.evaluation')); ?></label>
                                    </span>
                                </div>
                                <textarea readonly="readonly" cols="80" rows="5" class="form-control" name="description"><?php echo e($contributor->evaluation); ?></textarea>  
                            </div>
                        </div>
	                    <div class="form-group">
	                    	<label><?php echo e(__('contributor.grade')); ?></label>:&nbsp;
	                    	<?php echo e($contributor->grade); ?>

						</div>                        
	                    <div class="form-group">
	                    	<label><?php echo e(__('contributor.start')); ?></label>:&nbsp;
	                    	<?php echo e($contributor->start); ?>

						</div>                        
	                    <div class="form-group">
	                    	<label><?php echo e(__('contributor.end')); ?></label>:&nbsp;
	                    	<?php echo e($contributor->end); ?>

						</div>                        
	                    <div class="form-group">
	                    	<a class="btn btn-primary" href="<?php echo e(url()->previous()); ?>">
	                    		<em class="fa fa-undo"></em>
	                    		<?php echo e(__('contributor.back')); ?>

	                    	</a>
						</div>
                    </form>
                </div>
            </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/c4hu-platform/resources/views/contributorshow.blade.php ENDPATH**/ ?>