<?php $__env->startSection('content'); ?>
<div>
            <div class="pageBody max-w-6xl mx-auto sm:px-6 lg:px-8">
		    	<?php echo $__env->make('popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
           		<h2><?php echo e(env('APP_NAME')); ?></h2>	
            	<img src="/images/logo.png" class="logo" />
				<?php if(count($errors) > 0): ?>
				   <div class = "alert alert-danger">
				      <ul>
				         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <li><?php echo e(__('contributor.'.$error)); ?></li>
				         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </ul>
				   </div>
				<?php endif; ?>            
                <div class="profileForm">
                	<form method="POST" action="<?php echo e(\URL::to('/contributor')); ?>" id="frmContributor">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="project_id" value="<?php echo e($contributor->project_id); ?>" />
                        <input type="hidden" name="user_id" value="<?php echo e($contributor->user_id); ?>" />
		            	<h3>
	                    <img class="avatar" src="<?php echo e($contributor->project_avatar); ?>" />
	                    <?php echo e($contributor->project_name); ?></h3>
	                    <p><?php echo e(__('contributor.status')); ?>: 
	                    <?php echo e(__('contributor.'.$contributor->project_status)); ?>

	                    <?php echo e(__('contributor.deadline')); ?>: 
	                    <?php echo e($contributor->project_deadline); ?></p>
						<h4><?php echo e(__('contributor.contributor')); ?></h4>						
						<p>
	                    <img class="avatar" src="<?php echo e($contributor->user_avatar); ?>" />
	                    <?php echo e($contributor->user_name); ?> 
	                    </p>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('contributor.status')); ?>

                                    </span>
                                </div>
                                <select name="status" id="status" class="form-control">
                                	<option value="appliciant"><?php echo e(__('contributor.appliciant')); ?></option>
                                	<option value="active"><?php echo e(__('contributor.active')); ?></option>
                                	<option value="inactive"><?php echo e(__('contributor.inactive')); ?></option>
                                	<option value="exited"><?php echo e(__('contributor.exited')); ?></option>
                                </select> 
                            </div>
                        </div>

	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('contributor.description')); ?>

                                    </span>
                                </div>
                                <textarea cols="80" rows="5" class="form-control" name="description"><?php echo e($contributor->description); ?></textarea>  
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('contributor.evaluation')); ?>

                                    </span>
                                </div>
                                <textarea cols="80" rows="5" class="form-control" name="evaluation"><?php echo e($contributor->evaluation); ?></textarea>  
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('contributor.grade')); ?>

                                    </span>
                                </div>
                                <input type="number" min="1" max="5" class="form-control" 
                                name="grade" value="<?php echo e($contributor->grade); ?>" />  
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('contributor.start')); ?>

                                    </span>
                                </div>
                                <input type="date" class="form-control" 
                                name="start" value="<?php echo e($contributor->start); ?>" />  
                            </div>
                        </div>
	                    <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <?php echo e(__('contributor.end')); ?>

                                    </span>
                                </div>
                                <input type="date" class="form-control" 
                                name="start" value="<?php echo e($contributor->end); ?>" />  
                            </div>
                        </div>
	                    
	                    
	                    <div class="form-group">
	                    	<button type="submit" class="btn btn-primary" id="btnSave">
	                    		<?php echo e(__('contributor.save')); ?>

	                    	</button>
						</div>
                    </form>
                </div>
            </div>
            <script type="text/javascript">
            	$(function() {
					$('#status').val("<?php echo e($contributor->status); ?>");            	
            	});
            </script>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/c4hu-platform/resources/views/contributor.blade.php ENDPATH**/ ?>