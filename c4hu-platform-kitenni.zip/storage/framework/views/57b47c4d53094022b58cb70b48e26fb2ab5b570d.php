<?php $__env->startSection('content'); ?>
<div>

	    	<?php echo $__env->make('popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            <div class="pageBody max-w-6xl mx-auto sm:px-6 lg:px-8">
           		<h2><?php echo e(env('APP_NAME')); ?></h2>	
            	<img src="/images/logo.png" class="logo" />
	            <div class="row">
	            	<h3><?php echo e($user->name); ?></h3>
	            	<h4><?php echo e(__('contributor.projects')); ?></h4>
						<table class="table table-bordered table-hover">
						    <thead>
						        <th></th>
						        <th>
						        	<a href="/contributors?page=1&orderfield=projects.name">
						        	<?php echo e(__('contributor.project_name')); ?>

						        	<?php if($contributors->orderField == 'projects.name'): ?>
						        		<?php if($contributors->orderDir == 'ASC'): ?>
						        			<em class="fa fa-caret-down"></em>
						        		<?php else: ?>
						        			<em class="fa fa-caret-up"></em>
						        		<?php endif; ?>
						        	<?php endif; ?>
						        	</a>
						        </th>
						        <th>
						        	<a href="/contributors?page=1&orderfield=contributors.status">
						        	<?php echo e(__('contributor.status')); ?>

						        	<?php if($contributors->orderField == 'contributors.status'): ?>
						        		<?php if($contributors->orderDir == 'ASC'): ?>
						        			<em class="fa fa-caret-down"></em>
						        		<?php else: ?>
						        			<em class="fa fa-caret-up"></em>
						        		<?php endif; ?>
						        	<?php endif; ?>
						        	</a>
						        </th>
						        <th>
						        	<a href="/contributors?page=1&orderfield=contributors.grade">
						        	<?php echo e(__('contributor.grade')); ?>

						        	<?php if($contributors->orderField == 'contributors.grade'): ?>
						        		<?php if($contributors->orderDir == 'ASC'): ?>
						        			<em class="fa fa-caret-down"></em>
						        		<?php else: ?>
						        			<em class="fa fa-caret-up"></em>
						        		<?php endif; ?>
						        	<?php endif; ?>
						        	</a>
						        </th>
						    </thead>
						    <tbody>
						        <?php if($contributors->count() == 0): ?>
						        <tr>
						            <td colspan="4"><?php echo e(__('contributor.notrecords')); ?></td>
						        </tr>
						        <?php endif; ?>
						
						        <?php $__currentLoopData = $contributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						        <tr>
						            <td><img class="avatar" src="<?php echo e($contributor->project_avatar); ?>" /></td>
						            <td><a href="/project/<?php echo e($contributor->project_id); ?>">
						            	<?php echo e($contributor->project_name); ?>

						            	</a><br />
						            	<?php echo e(__('contributor.'.$contributor->project_status)); ?>

						            	</td>
						            <td><?php echo e(__('contributor.'.$contributor->status)); ?></td>
						            <td><?php echo e($contributor->grade); ?></td>
						        </tr>
						        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						    </tbody>
						</table>
						<?php echo e($contributors->links()); ?>

						<p>
						    <?php echo e($contributors->count()); ?> / <?php echo e($contributors->total()); ?> 
						</p>
	            </div>
	            <div class="buttons">
					<a class="ntm btn-primary" href="<?php echo e(url()->previous()); ?>">	            
		            	&nbsp;<em class="fa fa-undo"></em>
		            	<?php echo e(__('contributor.back')); ?>&nbsp;
		            </a>	
	            </div>
            </div>
</div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/c4hu-platform/resources/views/profileprojects.blade.php ENDPATH**/ ?>