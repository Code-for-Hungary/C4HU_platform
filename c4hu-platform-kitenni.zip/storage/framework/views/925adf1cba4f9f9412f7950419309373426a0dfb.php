<?php $__env->startSection('content'); ?>
<div id="welcome" class="pageBody max-w-6xl mx-auto sm:px-6 lg:px-8">
	<div class="intro">
       	<div style="text-align:center; width:auto; float:right;
       	    padding:5px; margin:5px; background-color:#efdb9e;
       	    border-radius:5px;">
       		<h3>Test loginok:</h3>
       		demo@test.hu / 12345678<br />
       		admin@test.hu / 12345678
       	</div>
       	<a href="#container" class="btn btn-secondary"><?php echo e(__('welcome.description')); ?></a>
    </div>   	
    <div class="welcome-container">
       	<a name="container"></a>
       		<h2><?php echo e(env('APP_NAME')); ?></h2>
       		<img src="/images/logo.png" />
			<p>NGO -k új web oldalainak kialakításához, meglévő  web 
				oldalainak fejlesztéséhez, üzemeltetéséhez önkéntesek toborzása, támogatás nyújtása. 
				Az igények és a jelentkező önkéntesek egymásra találásának elősegítése.
				Erre a web oldalra regisztrálhatnak weboldalt működtető vagy azt tervező NGO -k 
				és önkéntesek akik web oldal müködtetésre, fejlesztésre vállalkoznak. 
				Mindkét csoport a megszokott módon regisztrálhat usernév+jelszó megadásával 
				vagy facebook/google/github segítségével.
			</p>
			<p>
				A weboldal működtető NGO -k megadják a weboldalakkal kapcsolatos elvárásaikat  
				adatokat, valamint azt, hogy milyen feladatra keresnek önkénteseket.
				Az önkéntesek böngészhetik a feltöltött adatokat, keresési lehetőség, szűrési 
				lehetőség is van,  Ha vállalkoznak egy feladat elvégzésére, azt egy gombra 
				kattintással jelezhetik, .Egy link segitségével emailt küldhetnek 
				az NGO -nak.
			</p>
			<p>
				A weboldal üzemeltető NGO a kapcsolatfelvétel után jelezni tudja a rendszerben, 
				hogy a feladat folyamatban van, illetve a munka elvégzése után a feladat 
				lezárását is. Illetve törölhetik az önkéntes jelentkezését.Továbbá értékelheti 
				az önkéntes munkáját is (szöveges értékelés, és pontszám).
			</p>
			<p>
				Az önkéntesek visszavonhatják saját jelentkezésüket, addig amíg a feladat 
				státusza még “feladat” állapotot mutat.
				A weboldalon a regisztrált önkéntesek listája is böngészhető, publikus 
				profil adatok lekérdezhetőek és láthatóak a róluk adott értékelések is. 
				Nekik is lehet link segítségével email küldeni (az email cím itt sem publikált)
			</p>
	</div>
</div>			
<?php $__env->stopSection(); ?>
            

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/LaravelSocialite/resources/views/welcome.blade.php ENDPATH**/ ?>