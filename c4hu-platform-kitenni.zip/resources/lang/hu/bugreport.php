<?php
return [
    "reportForm" => "Hibajelzés",
    "description" => "Hiba leírása",
    "taskInfo" => "Információk a programozók számára",
    "help" => "A fenti információk segítik a programozókat a hiba behatárolásában.
                Ha ez olyan bizalmas infokat tartalmaz amit nem akar a programozokkal megosztani; cserélje azokat csillag karakterekre!",
    "send" => "Beküldés",
    "emailSent" => "E-mail elküldve a rendszergazdának. Köszönjük segítségét."
];