<?php
return [
	"Register" => "Regisztrálás",
	"Name" => "Publikus név (becenév)",
	"Email" => "E-mail",
	"Password" => "Jelszó",
	"ConfirmPassword" => "Jelszó ismét"
];