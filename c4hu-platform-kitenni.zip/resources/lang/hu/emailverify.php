<?php
return [
	"home" => "Kezdőlap",
	"title" => "Fiók E-mail ellenörzés szükséges",
	"send" => "Ellenörző E-mail küldése",
	"help" => "A fennti gombra kattintás után, ellenörizze a postaládáját, és kattintson az ellenörző levélben lévő linkre!",
	"mailSubject" => "E-mail ellenörzés, fiók aktiválás",
	"mailTitle" => "E-mail ellenörzés, fiók aktíválás",
	"mailText" => "Az E-mail ellenörzéshez és a fiók aktíválásához kattints az alábbi linkre",
	"emailSended" => "Aktíváló e-mail elküldve.",
	"successActivated" => "e-mail cím ellenörzés sikeres, fiók aktíválva"
];