<?php
return [
	"policy1" => "Adatkezelési leírás",
	"policy2" => "Adatkezelési szabályzat",
	"policy3" => "Adatkezelési nyilvántartás",
	"impressum" => "Impresszum",
	"licence" => "Licensz",
	"bugreport" => "Hibajelzés",
	"source" => "Forrás kód",
	"cookieInfo" => "Ennek a web oldalnak a használatához, szükség van két un. 'munkamenet csoki' kezelés engedélyezésére. Lásd az adatkezelési leírást!",
	"cookieEnabled" => "Munkamenet csoki kezelés engedélyezve",
	"cookieEnable" => "Csoki kezelés engedélyezése",
	"cookieDisable" => "Csoki kezelés letiltása"
];