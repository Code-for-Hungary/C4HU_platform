<?php
return [
	"Signup" => "Belépés",
	"Password" => "Jelszó",
	"PleaseSignIn" => "Bejelentkezés",
	"RememberMe" => "Emlékezzen rám",
	"NotSignin" => "Még nincs fiókod?",
	"Regist" => "Regisztrálás",
	"SocialLogin" => "Alternatív belépési lehetőségek",
	"ForgetPassword" => "Elfelejtettem a jelszavam",
	"ResendActivateEmail" => "Aktíváló E-mail újra küldése",
	"emailSended" => "Levél elküldve",
	"ResetPassword" => "Új jelszó megadása",
	"Email" => "E-mail cím",
	"Password" => "Jelszó",
	"ConformPassword" => "Jelszó újra",
	"SendPasswordResetLink" => "Új jelszó igénylő link küldése E-mailben"
];