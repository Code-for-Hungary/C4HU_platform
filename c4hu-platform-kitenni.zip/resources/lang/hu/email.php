<?php
return [
    "sendEmail" => "Email küldése",
    "to" => "Címzett",
    "from" => "Feladó",
    "subject" => "Tárgy",
    "body" => "Szöveg",
    "notfound" => "Nincs címzett.",
    "back" => "Mégsem",
    "send" => "Küldés",
];