<?php
return [
	"home" => "Kezdőlap",
	"signin" => "Belépés",
	"profile" => "Profil",
	"login" => "Bejelentkezés",
	"logout" => "Kijelentkezés",
	"regist" => "Regisztrálás",
	"search" => "Keresés",
	"projects" => "Projektek",
	"volunters" => "Önkéntesek",
    "sysadmins" => "Rendszergazdák"
];