@extends('layouts.app')
@section('content')
<div>
        <div>
            <div class="pageBody">
            <?php include $fname; ?>
            </div>
        </div>
</div>
@endsection
