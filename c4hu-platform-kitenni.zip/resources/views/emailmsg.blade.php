<div>
<pre>
<code>
{{ $body }}
</code>
</pre>
</div>
<p>Feladó: {{ $fromName }}  {{ $fromEmail }}

