<h2>{{ __('emailverify.mailTitle') }}</h2>
<p>{{ __('emailverify.mailText') }}</p>
<p><a href="{{ $url }}">{{ $url }}</a></p>

